﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int[] array = new int[10];
        int[] indices = new int[10];

        // Заполнение массива случайными числами от -10 до 10
        for (int i = 0; i < 10; i++)
        {
            array[i] = random.Next(-10, 11); // [-10, 10]
            indices[i] = i;
        }

        // Сортировка индексов по значениям массива
        for (int i = 0; i < 10 - 1; i++)
        {
            for (int j = i + 1; j < 10; j++)
            {
                if (array[indices[i]] > array[indices[j]])
                {
                    // Обмен индексов
                    int temp = indices[i];
                    indices[i] = indices[j];
                    indices[j] = temp;
                }
            }
        }

        // Вывод результатов
        Console.WriteLine("Исходный массив:");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"[{i}] = {array[i]}");
        }

        Console.WriteLine("\nМассив индексов в порядке возрастания значений:");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"[{i}] = индекс {indices[i]} (значение {array[indices[i]]})");
        }

        Console.WriteLine();
    }
}