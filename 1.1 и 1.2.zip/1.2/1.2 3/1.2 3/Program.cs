﻿using System;

class Program
{
    static bool IsPrime(int number)
    {
        if (number < 2) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;

        for (int i = 3; i * i <= number; i += 2)
        {
            if (number % i == 0)
                return false;
        }
        return true;
    }

    static void Main()
    {
        Console.Write("Введите количество простых чисел K: ");
        int k = int.Parse(Console.ReadLine());

        int count = 0;
        int number = 2;
        int numbersInLine = 0;

        Console.WriteLine($"Первые {k} простых чисел:");

        while (count < k)
        {
            if (IsPrime(number))
            {
                Console.Write(number.ToString().PadLeft(5));
                count++;
                numbersInLine++;

                if (numbersInLine == 10)
                {
                    Console.WriteLine();
                    numbersInLine = 0;
                }
            }
            number++;
        }

        if (numbersInLine != 0)
            Console.WriteLine();
    }
}