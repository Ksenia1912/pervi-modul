﻿using System;
using System.Collections.Generic;

class Program
{
    static bool IsConsonant(char c)
    {
        char lowerC = char.ToLower(c);
        string consonants = "бвгджзйклмнпрстфхцчшщ";
        return consonants.Contains(lowerC);
    }

    static void Main()
    {
        Console.Write("Введите размер массива K: ");
        int k = int.Parse(Console.ReadLine());

        Random random = new Random();
        char[] originalArray = new char[k];
        char[] russianAlphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя".ToCharArray();

        // Заполнение исходного массива случайными русскими буквами
        for (int i = 0; i < k; i++)
        {
            originalArray[i] = russianAlphabet[random.Next(russianAlphabet.Length)];
        }

        // Создание массива только с согласными буквами
        List<char> consonantsList = new List<char>();
        foreach (char c in originalArray)
        {
            if (IsConsonant(c))
                consonantsList.Add(c);
        }

        char[] consonantsArray = consonantsList.ToArray();

        // Вывод результатов
        Console.WriteLine("Исходный массив:");
        foreach (char c in originalArray)
        {
            Console.Write(c + " ");
        }
        Console.WriteLine();

        Console.WriteLine("Массив согласных букв:");
        foreach (char c in consonantsArray)
        {
            Console.Write(c + " ");
        }
        Console.WriteLine();
    }
}