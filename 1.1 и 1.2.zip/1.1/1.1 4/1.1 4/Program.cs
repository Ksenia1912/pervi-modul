﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите ваш возраст: ");
        int age = Convert.ToInt32(Console.ReadLine());

        if (age >= 18)
        {
            Console.WriteLine("Вы можете получить водительские права");
        }
        else
        {
            Console.WriteLine("Вы не можете получить водительские права (требуется возраст 18 лет и старше)");
        }
    }
}