﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите радиус круга: ");
        double radius = Convert.ToDouble(Console.ReadLine());

        double area = Math.PI * Math.Pow(radius, 2);
        Console.WriteLine($"Площадь круга с радиусом {radius} равна {area:F2}");
    }
}